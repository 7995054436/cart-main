const orderModel = require('./cake.model')
const mongoose=require('mongoose')
mongoose.connect('mongodb://127.0.0.1:27017/cloudnative')
console.log("connection successful")

exports.giveRating = (req, res) => {
    let cakename = req.params.name;
    let cakerate = req.query.rating;
    orderModel.updateMany({"name": `${cakename}`}, {$set: {"rating": `${cakerate}`}})
    .then(result => res.status(201).send({message: `Successfully rated`}))
    .catch(error => res.status(500).send(`Internal server error`));;

}