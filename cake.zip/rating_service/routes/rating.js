var express = require('express');
var router = express.Router();
var ratingController = require('./api/cakeController')
router.post('/:name',ratingController.giveRating)
module.exports = router