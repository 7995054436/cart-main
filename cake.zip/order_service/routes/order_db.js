var express = require('express');
var router =express.Router();
const cakeController=require('./api/cakeController')
router.post('/add',cakeController.addItemToCart);
router.get('/display',cakeController.displayOrder);
router.get('/checkout',cakeController.getcheckout);
module.exports=router;