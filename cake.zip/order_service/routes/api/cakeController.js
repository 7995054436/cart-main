const orderModel = require('./cake.model')
const mongoose=require('mongoose')
mongoose.connect('mongodb://127.0.0.1:27017/cloudnative')
console.log("connection successful")
/*
let cakeList = [];
exports.addCakes = (req, res) => {
    Order.find({name: req.params.name}, {_id:0})
    .then(cake => {
        if(cake.length != 0) {
            cakeList.push(cake[0]);
            res.status(200).send({message: `Cake added sucessfully`})
        }
        else
            res.status(404).send({message: `Cake details not found`});
    })
    .catch(error => res.status(500).send(`Internal server error`));
}
*/

exports.addItemToCart = (req, res) => {
    let insertObject = {
        cakeid: req.body.cakeid,
        name: req.body.name,
        price: req.body.price,
        image: req.body.image
    }
    orderModel.create(insertObject, (err, data) => {
        if (err) {
            console.log("error : ", err);
            res.json(err);
        } else {
            console.log('data inserted', data);
            res.json(data);
        }
    })
}
exports.displayOrder = (req, res) => {
    orderModel.find({}, (err, data) => {
        if (err) {
            res.send(err);
        } else {
            res.json(data);
        }
    }
    )
}
exports.getcheckout = (req,res)=>{
    orderModel.find({}, (err, data) => {
        if (err) {
            res.send(err);
        } else {
            res.json({messege:"ordered successfully" ,data});
        }
    }
    ).sort({_id:-1}).limit(1)

}