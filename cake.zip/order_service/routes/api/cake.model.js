const mongoose= require('mongoose')
const orderSchema = new mongoose.Schema({
    name:String,
    price:Number,
    image:String,
    cakeid:Number,
    rating:Number
},
{collection:'orders'});
module.exports = mongoose.model('orders',orderSchema)